# Netflix
It is a simple website using CSS, HTML, JAVASCRIPT to design netflix homepage
